<div class ="alinhado-centro borda-base espaco-vertical">
<div id="footer" class="borda-topo espaco-vertical">
<nav class="navbar navbar-default navbar-fixed-bottom">

      <div class="container"><center>
       Todos os direitos reservados</center>
      </div><!-- /.container -->
    </nav><!-- /.navbar -->
  </div>
  </div>
