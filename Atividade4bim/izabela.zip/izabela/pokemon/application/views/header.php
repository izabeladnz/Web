<body style="background-color:#FFC0CB;">
<div class="container-fluid" >
    
  
    <nav class="navbar navbar-default">
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-3">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button><img src="http://localhost/izabela/pokemon/assets/img/01.jpg" style=" width: 50px;height: 50px;">
          <a class="navbar-brand" href="#">POKEMON GO</a>
        </div>
    
       
    
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar-collapse-4">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="http://localhost/izabela/pokemon/index.php/Cadastro">Novo</a></li>
            <li><a href="http://localhost/izabela/pokemon/index.php/Home">Pokemons</a></li>
            <li><a href="http://localhost/izabela/pokemon/index.php/Login">Sair</a></li>
          
          </ul>
          
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container -->
    </nav><!-- /.navbar -->
</div><!-- /.container-fluid -->

