<center>
<div id="homebody">
<div class="[ container ]">
    <div class="[ row ]">
        <div class="[ col-xs-12 col-md-offset-1 col-md-10 text-center ]">
             	<div class="row-fluid">
			<div class="col-md-6">
          <div class="panel panel-default">
            <div class="panel-heading"> Pokemons</div>
            <div class="panel-body">
              <div class="table-responsive">
                <table class="table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Nome</th>
                      <th>Data</th>
                      <th>Tipo</th>
					  <th>Editar</th>
					   <th>Excluir</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr class="success">
                      <td>1</td>
                      <td>Venonate</td>
                      <td>15/01/2014</td>
                      <td>Verde</td>
					 <td> <a href="http://localhost/izabela/pokemon/index.php/Editar"><button type="button" class="btn btn-sm btn-success">Editar</button></td>
					 <td> <button type="button" class="btn btn-sm btn-danger">X</button></td>
                    </tr>
                    
                    <tr class="warning">
                      <td>2</td>
                      <td>Bulbasaur</td>
                      <td>16/02/1989</td>
                      <td>Laranja</td>
					 <td> <a href="http://localhost/izabela/pokemon/index.php/Editar"><button type="button" class="btn btn-sm btn-success">Editar</button></td>
					 <td> <button type="button" class="btn btn-sm btn-danger">X</button></td>
                    </tr>
                    <tr class="danger">
                      <td>3</td>
                      <td>Pikachu</td>
                      <td>18/02/1999</td>
                      <td>Vermelho</td>
					  <td><a href="http://localhost/izabela/pokemon/index.php/Editar"> <button type="button" class="btn btn-sm btn-success">Editar</button></td>
					 <td> <button type="button" class="btn btn-sm btn-danger">X</button></td>
                    </tr>


               

                  </tbody>
                </table>
              </div>
            </div>
        </div>
    </div>
</div>


		<div class ="alinhado-centro borda-base espaco-vertical">
  	</div>

<center>

</div>
  </div>
 </div>
