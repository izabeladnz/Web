<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	//public function index()
	//{
		//$this->load->view('welcome_message');
		//$data['mensagem'] = "Olá Mundo!";
		//$this->load->view('ola_mundo', $data);
	//}
	public function index () {
		$data ['postagens'] = $this->db->get('postagens')->result() ;
		$this->load->view('postagens', $data);
	}
	public function detalhes($id){
		$this->db->where('id', $id);
		$data ['postagem'] = $this->db->get('postagens')->result();
		$data ['postagens'] = $this->db->get('postagens')->result();
		$this->load->view('detalhes_postagem', $data);
	}
}
